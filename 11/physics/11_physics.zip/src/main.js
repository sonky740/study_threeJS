import example from './ex03';

example();
